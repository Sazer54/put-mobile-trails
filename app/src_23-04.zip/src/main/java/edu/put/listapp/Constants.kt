package edu.put.listapp

object Constants {
    const val HEADER_TEXT = "The available tracks:"
}